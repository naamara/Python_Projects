import json
import random
import getpass
import threading

user = []

def play():
    if len(user) == 0:
        print("You must first login before taking exam.")
    elif len(user) == 2:
        print("\n==========EXAMINATION==========\n")
        print(f"\n==========YOU CAN START {username}==========")
        print("\n============stay safe===============")
        
        score = 0
        with open("assets/questions.json", 'r+') as f:
            j = json.load(f)
            
            for i in range(10):
                no_of_questions = len(j)
                ch = random.randint(0, no_of_questions - 1)
                print(f'\nQ{i+1} {j[ch]["question"]}\n ')
                for option in j[ch]["options"]:
                    print(option)
                answer = input("\nEnter your answer: ")
                if j[ch]["answer"][0] == answer[0].upper():
                    print("\nYou are correct")
                    score +=1
                else:
                    print("\nYou are incorrect")
                    print('\n++++++++++++++++++++++++')
                    print(f'\n Correct answer is {j[ch]["answer"][0]}')
                    del j[ch]
            print("=====================================")
            if score >= 5 and score < 10  :
                print(f'Congratulations! you did well \nFINAL SCORE: {score}')
            elif score == 10:
                print(f'Outstanding Job \nFINAL SCORE: {score}')
            elif score < 5:
                print(f'\nYou scored Low \nFINAL SCORE: {score}')

def examQuestions():
    if len(user) == 0:
        print("You must first login as a teacher before adding questions")
    elif len(user) == 2:
        ## only teacher is User 'gbolahan', password: 'gbolahan'
        if user[1] == "TEACHER" or user[1] == "teacher":
            print('\n=============ADD QUESTIONS============\n')
            ques = input("Enter the questions that you want to add:\n")
            opt = []
            print("Enter the 4 options with character initials (A, B, C, D)")
            for alphabets in range(4):
                opt.append(input())
            ans = input("Enter the answer: \n")
            with open("assets/questions.json", 'r+') as f:
                questions = json.load(f)
                dic = {"question": ques, "options": opt, "answer": ans}
                questions.append(dic)
                f.seek(0)
                json.dump(questions, f)
                f.truncate()
                print("Question successfully added.")
        else:
            print("You don't have access to adding questions. Only teachers are allowed to add questions. ")

def createAccount():
    print("\n=============CREATE ACCOUNT=========")
    username = input("Enter your USERNAME: ")
    full_name = input("Enter your FULLNAME: ")
    
    password = getpass.getpass(prompt= 'Enter your PASSWORD: ')
    with open('assets/user_accounts.json', 'r+') as  user_accounts:
        users = json.load(user_accounts)
        if username in users.keys():
            print("An account of this username already exists. \nPlease enter the login panel.")
        else:
            users[username] = [password, "STUDENT", full_name]
            user_accounts.seek(0)
            json.dump(users, user_accounts)
            user_accounts.truncate()
            print("Account created successfully! ")



def loginAccount():
    print("\n=============LOGIN PANEL=============")
    global username
    username = input("USERNAME: ")
    password = getpass.getpass(prompt= 'PASSWORD: ')
    with open('assets/user_accounts.json', 'r') as user_accounts:
        users = json.load(user_accounts)
    if username not in users.keys():
        print("An account of that doesn't exist. \n Please create an account first. ")
    elif username in users.keys():
        if users[username][0] != password:
            print("Your password is incorrect. \n Please enter the correct password and try again.")
        elif users[username][0] == password:
            print(f"You have successfully logged in as {username}. \n Now proceed")
            user.append(username)
            user.append(users[username][1])



    

def logout():
    global user
    if len(user) == 0:
        print("You are already logged out. ")
    else:
        user = []
        print("You have been logged out successfully")

def instructions():
    print('''\n==========INSTRUCTIONS OF THE EXAM==========
1. Each round consists of 10 random questions. To answer, you must press A/B/C/D (case-insensitive).
Your final score will be given at the end.
2. You can't go back to previous answered questions.
3. Each question consists of 1 point.
4. There's no negative point for wrong answers.
5 . You can create an account from ACCOUNT CREATION panel.
6. You can login using the LOGIN PANEL. Currently, the program can only login and not do anything more.
	''')

def about():
    print('''\n==========ABOUT US==========
Scholar Gbolahan Online Exam. \nThis project was created for the benefit of continuous study and evaluation during this Corona Period.
We hope you are staying safe and healthy.
 We love you and want to see you after this Period. ''')


if __name__ == "__main__":
    choice = 1
    while choice != 7:
        print('\n=============WELCOME TO ONLINE EXAM (Stay safe)==========')
        print(f'-----------------------------------------------------------')
        print('1. START EXAM')
        print('2. ADD EXAM QUESTIONS')
        print('3. CREATE AN ACCOUNT')
        print('4. LOGIN PANEL')
        print('5. LOGOUT PANEL')
        print('6. INSTRUCTIONS ON HOW TO GO THROUGH WITH THE EXAM ')
        print('7. EXIT')
        print('8. ABOUT US')

        choice = int(input('ENTER YOUR CHOICE: '))
        if choice ==1:
            play()
        elif choice ==2:
            examQuestions()
        elif choice == 3:
            createAccount()
        elif choice == 4:
            loginAccount()
        elif choice == 5:
            logout()
        elif choice == 6:
            instructions()
        elif choice == 7:
            print('Thank you.')
            exit()
        elif choice == 8:
            about()
        else:
            print('WRONG INPUT. ENTER THE CHOICE AGAIN')