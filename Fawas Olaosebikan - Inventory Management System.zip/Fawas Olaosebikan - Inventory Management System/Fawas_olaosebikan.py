#!/usr/bin/env python
# coding: utf-8

# """ PRODUCT INVENTORY FOR A WHOLESALE OUTLET """
# This project is intended to manage the inventory of a wholesale outlet which buys goods in bulk directly from the manufacturer and sells it back in whole sales to retailers.

# SECTION A
# This is the input section of the program. It is expected to request for the details of the goods newly purchased and then records it in its data base. The records should include Name of the product, Description of the product, Unit cost of the product, Quantity of the product and the product ID.

# In[76]:


import csv
import sys
import pandas as pd


# In[77]:


# the products data are going to be stored in csv format (database)
# product_data.csv = name of the product database


def data_entry(y, products):
    """This function helps create a new database or append to an already existing database using csv module"""
    columns = ["name", "id", "description", "unit_cost", "qty"]
    if y == 1:
        # creating a new database using csv module

        with open("product_data.csv", mode="a") as product_data:
            writer = csv.DictWriter(product_data, fieldnames=columns)

            writer.writeheader()
            writer.writerow(products)
            print("product database named product_data.csv created successfully!")

    else:
        with open("product_data.csv", mode="a") as product_data:
            writer = csv.DictWriter(product_data, fieldnames=columns)
            writer.writerow(products)
            print("Product details entered successfully!")


# In[78]:


# iniating a class Poduct that creates a blueprint for the details of a product
class Product():
    def __init__(self, product_details):
        for key, value in product_details.items():
            setattr(self, key, value)


class Process(Product):
    """This class carries out processing on the given details of a product."""

    @property
    def sp(self):
        """This determines the selling price of a product."""
        cost = eval(self.unit_cost)
        if cost <= 1000:
            return cost + (0.02 * cost)
        elif 1000 < cost < 5000:
            return cost + (0.05 * cost)
        elif 5000 < cost < 10000:
            return cost + (0.07 * cost)
        elif cost > 10000:
            return cost + (0.1 * cost)

    @property
    def avail_qty(self):
        """This determines the quantity of a product in stock"""
        return self.qty

    def purchase(self, pur_qty):
        """This evaluate the puuchase of a product and effect it on the database"""
        qt = eval(self.qty)
        qt -= pur_qty
        return qt


# In[85]:


# asking the user what activity he/she wants to do
# NEW STOCK : refers to goods purchased from the manufacturer and needs to be entered into the system
# PURCHASE: refers to when retailers when to make purchase
# REPORT : refers to request for daily or weekly report

pur_rec = dict()


def main_application1():
    """This function is to be used for existing user as it only appends only to an already existing csv database!"""
    ver = True
    while ver:
        print()

        act = eval(input("1)NEW STOCK\t 2)PURCHASE\t 3)REPORT\t 4)BACK  \n"))

        if act == 1:
            print()

            print("Kindly enter the details of the new products one after the other.")

            while 1:
                print()
                name = input("Name of the product: ")
                description = input("Product Description: ")

                print("""
                       Pepsi = PI
                       Fanta = FA
                       Sprite = SE
                       Coke = CE
                       Mirinda = MI
                       Bigi Cola = BC
                       Bigi Lemon = BL
                       Bigi Tropical = BT
                       Bigi Apple = BA
                       Bigi Orange = BO
                       """)  # product ID are predefinned, user is expected to check for the ID of the product and enter it

                p_id = input("Product ID: ")

                cost = eval(input("Cost per Unit: #"))
                qty = eval(input("Quantity: "))
                print()  # insert a line spacing

                # storing input product details into a dictionnary

                product_details = {
                    "name": name,
                    "id": p_id.lower(),
                    "description": description.lower(),
                    "unit_cost": cost,
                    "qty": qty
                }
                print(product_details, end="\n\n")  # insert double line spacing

                # storing the details temporarily in a text file

                # storing the data of the product into .csv document using data_entry function defined above
                data_entry(2, product_details)

                next_action = eval(input("1)Add another product \t 2)Finish \n"))

                if next_action == 2:
                    break  # this is to stop the main while loop and it is only executed when the user is done enetering the products

        elif act == 2:
            # this take in a purhase order or request, output the selling price and the available quantity

            b = True  # arbitrary variable
            while b:
                print("""
                       Pepsi = PI
                       Fanta = FA
                       Sprite = SE
                       Coke = CE
                       Mirinda = MI
                       Bigi Cola = BC
                       Bigi Lemon = BL
                       Bigi Tropical = BT
                       Bigi Apple = BA
                       Bigi Orange = BO
                       """)
                products = input("Name or Product_ID: ")
                req = products.lower()
                with open("product_data.csv",
                          mode="r") as stock:  # this read data in the .csv database into a dictionary
                    # stock_data : this a variable into which the stock of products in the database is transferred to

                    stock_data = csv.DictReader(stock)

                    # count variable was created to access the content of the product database and
                    # check if it contains required product to be

                    count = []
                    count2 = []  # this is similar to stock_data variable

                    # a copy of the data read from the csv document was created to enable check for inclusion of required product
                    for row in stock_data:
                        count2.append(row)

                        count += (dict(row)).values()

                    sn = -1  # arbitrary contract to keep track of iteration and it is -1 coz i want my first to be 0

                    if req in count:

                        with open("product_data.csv", mode="w") as product_data:

                            columns = ["name", "id", "description", "unit_cost", "qty"]
                            writer = csv.DictWriter(product_data, fieldnames=columns)

                            writer.writeheader()

                        print()
                        print(f"{req} is available!")

                        for prod in count2:  # prod is an arbitrary variable used for iteration

                            sn += 1

                            if req in prod.values():
                                print()
                                print(dict(prod))

                                # converting the prod containing the required product to a dictionnary and
                                # hence instantiating its object using class Process.

                                product = Process(dict(prod))

                                print(f" selling price: #{product.sp}, Available quantity: {product.avail_qty}")

                                print()

                                # starting another loop to confirm or deny purchase

                                d = True  # arbitrary input
                                while d:
                                    order = eval(input("1)Place Order \t 2)End Order \n"))
                                    if order == 1:
                                        # This proceed to finalise the purchase
                                        purchased = eval(input("Quantity required:  "))
                                        print()
                                        qt = product.purchase(purchased)

                                        count2[sn]["qty"] = qt  # updating the stock after purchase has been made

                                        # the following code is to enable record daily purchase

                                        pur_rec = dict(prod)
                                        pur_rec["selling_price"] = product.sp
                                        pur_rec["qty_purchased"] = purchased

                                        pur_record = {count2[sn]["id"]: pur_rec}
                                        df = pd.DataFrame(data=pur_record).T

                                        df.to_excel("total_purchases.xlsx")  # recording purchase in an excel document

                                        # after a purchase has been completed, the data of the product purchased
                                        # along the remaining quantity is to be entered into another document known as the sales document

                                        d = False  # used to end the while loop

                                        print("Purchase successful!")
                                    elif order == 2:
                                        print()
                                        print("Order cancelled!", end="\n\n")

                                        d = False

                                    else:
                                        print()
                                        print("Invalid Input")

                            # overwriting the data in the csv file
                            with open("product_data.csv", mode="a") as product_data:

                                writer = csv.DictWriter(product_data, fieldnames=columns)
                                writer.writerow(prod)

                    else:  # req not in count:
                        print()  # insert a blank line
                        print(f"{req} not available!", end="\n\n")

                    # inquire if there are more products to be ordered
                    print("Do you want to order another product ?")

                    c = True  # arbitrary variable
                    while c:
                        print()
                        new_order = eval(input("1) Yes\t2)No  "))
                        if new_order == 1:
                            c = False
                        elif new_order == 2:
                            print("Transaction completed!")
                            c = False
                            b = False
                        else:
                            print()
                            print("Invalid input!")


        elif act == 3:
            # this gives a report of the product stock and the day's sales

            while 1:
                rep = eval(input("1) Products in Stock \t 2)Sale's record \t3)Quit \n"))
                if rep == 1:

                    df = pd.read_csv("product_data.csv")  # reading the .csv product database using panda module
                    print()
                    print(df)

                    break

                elif rep == 2:

                    df = pd.read_excel("total_purchases.xlsx",
                                       index_col=0)  # reading purchase record from the excel document

                    print()

                    print(df)

                    break
                elif rep == 3:
                    break
                else:
                    print("Invalid Input!")
            pass
        elif act == 4:
            print("Have a nice day!")
            ver = False
        else:
            print("Invalid input!")


# In[86]:


# asking the user what activity he/she wants to do
# NEW STOCK : refers to goods purchased from the manufacturer and needs to be entered into the system
# PURCHASE: refers to when retailers when to make purchase
# REPORT : refers to request for daily or weekly report


def main_application2():
    """This function is to be used for new users as it creates a new csv database!"""
    ver = True

    # asking the user what activity he/she wants to do
    # NEW STOCK : refers to goods purchased from the manufacturer and needs to be entered into the system
    # PURCHASE: refers to when retailers when to make purchase
    # REPORT : refers to request for daily or weekly report

    while ver:
        print()

        act = eval(input("1)NEW STOCK\t 2)RETURN  \n"))

        if act == 1:
            print()

            print("Kindly enter the details of the new products one after the other.")

            qn = 0  # arbitrary constant to keep count of iteration
            while 1:
                qn += 1
                print()
                name = input("Name of the product: ")
                description = input("Product Description: ")

                print("""
                       Pepsi = PI
                       Fanta = FA
                       Sprite = SE
                       Coke = CE
                       Mirinda = MI
                       Bigi Cola = BC
                       Bigi Lemon = BL
                       Bigi Tropical = BT
                       Bigi Apple = BA
                       Bigi Orange = BO
                       """)  # product ID are predefinned, user is expected to check for the ID of the product and enter it

                p_id = input("Product ID: ")

                cost = eval(input("Cost per Unit: #"))
                qty = eval(input("Quantity: "))
                print()  # insert a line spacing

                # storing input product details into a dictionnary

                product_details = {
                    "name": name.lower(),
                    "id": p_id.lower(),
                    "description": description.lower(),
                    "unit_cost": cost,
                    "qty": qty
                }
                print(product_details, end="\n\n")  # insert double line spacing

                # storing the data of the product into .csv document using data_entry function defined above

                data_entry(qn, product_details)  # this creates a new csv database

                next_action = eval(input("1)Add \t 2)Finish"))

                if next_action == 2:
                    break  # this is to stop the main while loop and it is only executed when the user is done enetering the products

            main_application1()
            ver = False
        elif act == 2:
            ver = False

        else:
            print("Invalid input!")


#     PROGRAM INITIATION
#  The program begins here!

# In[87]:


print("Welcome!", end="\n\n")

while 1:
    do = eval(input("1)EXISTING USER \t 2)NEW USER \t3)END \n "))
    if do == 1:
        # for existing user, a csv database would have already been created
        main_application1()

    elif do == 2:
        # for new user, a new csv database would be created
        main_application2()

    elif do == 3:
        sys.exit(0)
    else:
        print("Invalid entry!")

# In[ ]:
