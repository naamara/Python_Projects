import date
import bookList

def borrowBook():
    success=False
    while(True):
        firstName=input("Borrower's first name (Alphabets only): ")
        if firstName.isalpha():
            break
        print("Error! Name contains non-alphabets")
    while(True):
        lastName=input("Borrower's last name (Alphabets only): ")
        if lastName.isalpha():
            break
        print("Error! Name contains non-alphabets")
            
    t="Borrow-"+firstName+".txt"
    with open(t,"w+") as f:
        f.write("               Library Management System  \n")
        f.write("                   Borrowed By: "+ firstName+" "+lastName+"\n")
        f.write("    Date: " + date.getDate()+"    Time:"+ date.getTime()+"\n\n")
        f.write("S.N. \t\t Bookname \t      Authorname \n" )
    
    while success==False:
        print("Please select a option below:")
        for i in range(len(bookList.bookname)):
            print("Enter", i, "to borrow book", bookList.bookname[i])
    
        try:   
            a=int(input())
            try:
                if(int(bookList.quantity[a])>0):
                    print("Book is available")
                    with open(t,"a") as f:
                        f.write("1. \t\t"+ bookList.bookname[a]+"\t\t  "+bookList.authorname[a]+"\n")

                    bookList.quantity[a]=int(bookList.quantity[a])-1
                    with open("books.txt","w+") as f:
                        for i in range(3):
                            f.write(bookList.bookname[i]+","+bookList.authorname[i]+","+str(bookList.quantity[i])+","+"$"+bookList.cost[i]+"\n")


                    #multiple book borrowing code
                    loop=True
                    count=1
                    while loop==True:
                        choice=str(input("Borrow more? Enter 'Y' to proceed and 'N' to quit. However you cannot borrow same book twice."))
                        if(choice.upper()=="Y"):
                            count=count+1
                            print("Please select an option below:")
                            for i in range(len(bookList.bookname)):
                                print("Enter", i, "to borrow book", bookList.bookname[i])
                            a=int(input())
                            if(int(bookList.quantity[a])>0):
                                print("Book is available")
                                with open(t,"a") as f:
                                    f.write(str(count) +". \t\t"+ bookList.bookname[a]+"\t\t  "+bookList.authorname[a]+"\n")

                                bookList.quantity[a]=int(bookList.quantity[a])-1
                                with open("books.txt","w+") as f:
                                    for i in range(3):
                                        f.write(bookList.bookname[i]+","+bookList.authorname[i]+","+str(bookList.quantity[i])+","+"$"+bookList.cost[i]+"\n")
                                        success=False
                            else:
                                loop=False
                                break
                        elif (choice.upper()=="N"):
                            print ("Thank you for borrowing books from us. ")
                            print("")
                            loop=False
                            success=True
                        else:
                            print("Please choose as instructed")
                        
                else:
                    print("Book is not available")
                    borrowBook()
                    success=False
            except IndexError:
                print("")
                print("Please choose book acording to the number.")
        except ValueError:
            print("")
            print("Please choose as suggested.")
