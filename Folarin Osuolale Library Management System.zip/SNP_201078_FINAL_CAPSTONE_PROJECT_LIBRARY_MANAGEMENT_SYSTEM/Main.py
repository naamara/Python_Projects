import Return
import bookList
import date
import Borrow

def start():
    while(True):
        print("        Welcome to the library management system     ")
        print("------------------------------------------------------")
        print("To view available books: Press 1")
        print("To borrow a book: Press 2")
        print("To return a book: Press 3")
        print("To exit: Press 4")
        try:
            a=int(input("Select from 1-4: "))
            print()
            if(a==1):
                with open("books.txt","r") as f:
                    lines=f.read()
                    print(lines)
                    print ()
   
            elif(a==2):
                bookList.bookList()
                Borrow.borrowBook()
            elif(a==3):
                bookList.bookList()
                Return.returnBook()
            elif(a==4):
                print("Thank you for using our library management system")
                break
            else:
                print("Please choose from 1-4")
        except ValueError:
            print("Please follow the instructions.")
start()
