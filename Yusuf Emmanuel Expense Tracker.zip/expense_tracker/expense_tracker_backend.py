import tkinter.messagebox
import sqlite3 as db
from datetime import datetime

# ======================= TO Setup The Database ====================
def init():
    '''
        Initialize a new database to store the
        expenditure
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()

    user_table = '''
    create table if not exists users (
        id INTEGER PRIMARY KEY,
        username string UNIQUE,
        fullname string,
        password string
    );
    '''

    expense_table = '''
        create table if not exists expenses (
            id INTEGER PRIMARY KEY,
            amount number,
            category string,
            message string,
            date string,
            user_id integer,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        '''

    income_table = '''
        create table if not exists incomes (
            id INTEGER PRIMARY KEY,
            amount number,
            source string,
            date string,
            user_id integer,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        '''

    budget_table = '''
            create table if not exists budget (
                id INTEGER PRIMARY KEY,
                amount number,
                user_id integer,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            '''

    cursor.execute(user_table)
    cursor.execute(expense_table)
    cursor.execute(income_table)
    cursor.execute(budget_table)
    conn.commit()


# ======================= Users Methods ===================================

def register_user(username, full_name, password):
    '''
    Gets the User information for storing in the Database
    Username: string
    full_name: string
    password: string
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
        INSERT INTO users values(
            {},
            '{}',
            '{}',
            '{}'
        )
    '''.format('Null', username, full_name, password)

    cursor.execute(sql)
    conn.commit()


# ======================== To View User =========================

def viewUsers():
    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
        select * from users
        '''.format()

    cursor.execute(sql)
    result = cursor.fetchall()
    return result


# ==================== To Login User ================================


def login_user(username, password):
    '''
    Gets the User input and the compare it with the database
    Username: string
    password: string
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = ("SELECT * FROM users WHERE username = ? AND password = ?")
    cursor.execute(sql, [username, password])
    global login_results
    login_results = cursor.fetchall()

    # if(results):
    #     tkinter.messagebox.showinfo("Success", "Login Successful")
    # # else:
    # #     tkinter.messagebox.showerror("Error", "Login Error")
    # #     exit()


# ==================== To Get User Id ============================

def getUserId(username, password):
    '''
        To get the user Id using the username and the password as parameter
    '''
    conn = db.connect("spent.db")
    cursor = conn.cursor()

    sql = ("SELECT id FROM users WHERE username = ? AND password = ?")
    cursor.execute(sql, [username, password])
    global auth
    auth = cursor.fetchall()

    if(auth):
        return auth[0][0]
    else:
        return -1

# ================================== expenses Methods ========================================

def add_expenses(amount, category, user_id, message=""):
    '''
    adds the expenditure in the database.
    amount: number
    category: string
    message: (optional) string
    '''

    date = str(datetime.now())
    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
        insert into expenses values(
            {},
            {},
            '{}',
            '{}',
            '{}',
            {}
        )
        '''.format('Null',amount, category, message, date, user_id)

    cursor.execute(sql)
    conn.commit()

# ========================= View Expenses Method =============================

def view_expenses(category=None):
    '''
    Returns a list of expenses of all user
    If a category is specified, it only returns info from that
    category
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    if(category):
        sql = '''
                select * from expenses where category = '{}'
                '''.format(category)
    else:
        sql = '''
                 select * from expenses
                 '''.format(category)

    cursor.execute(sql)
    results = cursor.fetchall()
    return results

# ========================== View User Expenses Method ===================================

def view_user_expenses(user_id,category=None):
    '''
    Returns a list of expenses of the login user
    If a category is specified, it only returns info from that
    category
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    if(category):
        sql = '''
                select * from expenses where category = '{}' and user_id = '{}'
                '''.format(category)
    else:
        sql = '''
                 select * from expenses
                 '''.format(category, user_id)

    cursor.execute(sql)
    results = cursor.fetchall()
    return results


# ============================= Total Expenses Method ===========================

def total_expenses(category=None):
    '''
    Returns the total expenses,
    If a category is specified, it only returns info from that
    category
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    if(category):
        sql = '''
                select sum(amount) from expenses where category = '{}'
                '''.format(category)
    else:
        sql = '''
                 select sum(amount) from expenses
                 '''.format(category)

    cursor.execute(sql)
    total_expenses = cursor.fetchone()[0]

    return total_expenses

# =========================== add Income Methods ========================================

def add_income(amount, source, user_id):
    '''
    Add the user income to the database.
    amount: number
    category: string
    message: (optional) string
    '''

    date = str(datetime.now())
    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
        insert into incomes values(
            {},
            {},
            '{}',
            '{}',
            {}
        )
        '''.format('Null', amount, source, date, user_id)

    cursor.execute(sql)
    conn.commit()

# =================================== View Income Method ==============================

def view_income():
    '''
    Returns the list of all user Income
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
            select * from incomes
        '''.format()
    cursor.execute(sql)
    results = cursor.fetchall()
    return results

# ================================ View User Income Method =======================================

def view_user_income(user_id):
    '''
    Return the list of a User Income Using the User Id
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
            select * from incomes where user_id = '{}'
        '''.format(user_id)
    cursor.execute(sql)
    results = cursor.fetchall()
    return results

# =================================== Total Income Method ==========================================

def total_incomes():
    '''
    Returns the total Income,
    If a category is specified, it only returns info from that
    category
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
            select sum(amount) from incomes
            '''.format()
    cursor.execute(sql)
    total_income = cursor.fetchone()[0]
    return total_income




# ============================ Add Budget Methods ====================================

def add_budget(amount,user_id):
    '''
    Add the user income to the database.
    amount: number
    category: string
    message: (optional) string
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
        insert into budget values(
            {},
            {},
            {}
        )
        '''.format('Null', amount, user_id)

    cursor.execute(sql)
    conn.commit()

# ============================ Update Budget Method ===============================

def update_budget(amount=30000):
    '''
    Add the user income to the database.
    amount: number
    category: string
    message: (optional) string
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
        update budget set amount= '{}' 
        '''.format(amount)

    cursor.execute(sql)
    conn.commit()

# ============================== View User Budget Method ==============================

def view_user_budget():
    '''
    Return the list of a User Income Using the User Id
    '''

    conn = db.connect("spent.db")
    cursor = conn.cursor()
    sql = '''
            select amount from budget
        '''.format()
    cursor.execute(sql)
    results = cursor.fetchall()
    return results


init()

