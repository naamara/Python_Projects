'''

    The Program is an expense tracking app which accepts a user login
    to secure the user from leak of expenses detail, if the login detail is not
    correct the program close immediately.

    The program as Features Like Add incomes, Add Expenses

    To Get access You can use the Username: Admin and Password: Password,
    You can also register an account
'''


# Importing Modules
from tkinter import *
import tkinter.messagebox
from tkinter import ttk
import expense_tracker_backend


class App(Tk):
    def __init__(self, *args, **kwargs):
        Tk.__init__(self, *args, **kwargs)

        # Setup Frame
        container = Frame(self)
        container.pack(side=TOP, fill=BOTH, expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (
        StartPage, RegistrationPage, DashboardPage, AddIncomePage, AddExpensesPage, ShowIncomePage, ShowExpensesPage):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(StartPage)

    def show_frame(self, context):
        frame = self.frames[context]
        frame.tkraise()


# ================================ Login Frame ===================================

class StartPage(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent, width=800, height=600)

        username = StringVar()
        password = StringVar()

        def login_onclick():
            while True:
                if (len(username.get()) > 0 and len(password.get()) > 0):
                    login = expense_tracker_backend.login_user(username.get(), password.get())

                    global user_id
                    user_id = expense_tracker_backend.getUserId(username.get(), password.get())
                    if(expense_tracker_backend.login_results):
                        tkinter.messagebox.showinfo("Sucessfull", "Login Sucessfull")
                        controller.show_frame(DashboardPage)
                        break
                    else:
                        login_error_info = tkinter.messagebox.askquestion("Login Error", "Do you have an account")
                        if(login_error_info == 'yes'):
                            tkinter.messagebox.showinfo("Info", "Input the correct login details")
                        else:
                            controller.show_frame(RegistrationPage)
                        break
                else:
                    tkinter.messagebox.showerror('Fill Field', 'Make Sure you Fill all Field')


        # Form Tittle
        label_title = Label(self, text='Sign in', font='Poppins 18', background=None)
        label_title.place(x=82, y=72.5, background=None)

        # Username Field
        label_username = Label(self, text='Username', font='Poppins 14', bg=None)
        label_username.place(x=82, y=150)

        entry_username = Entry(self, width=50, font='Poppins 14', textvariable=username)
        entry_username.place(x=82, y=200, background=None)

        # Password Field
        label_password = Label(self, text='Password', font='Poppins 14', bg=None)
        label_password.place(x=82, y=250)

        entry_password = Entry(self, width=50, font='Poppins 14', bg=None, textvariable=password)
        entry_password.place(x=82, y=300)

        # Sign in Button
        sign_in_button = Button(self, text='Sign In', width=59, font='Poppins 12', height=1, bg='blue', fg='white',
                                command=login_onclick)
        sign_in_button.place(x=82, y=350)

        question = Label(self, text='Not Having an Account?', font='Poppins 12', bg=None)
        question.place(x=82, y=410)

        sign_up_button = Button(self, text='Sign Up', width=59, font='Poppins 12', height=1, bg='white', fg='black',
                                command=lambda: controller.show_frame(RegistrationPage))
        sign_up_button.place(x=82, y=450)


# ================================= Registration Page ===================================

class RegistrationPage(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent, width=800, height=600)

        fullname = StringVar()
        username = StringVar()
        password = StringVar()
        confirm_password = StringVar()

        # Sign up Onclick function
        def sign_up_onclick():
            # Authentication and Validation
            if (len(fullname.get()) > 0 and len(username.get()) > 0 and len(password.get()) > 0 and len(
                    confirm_password.get()) > 0):
                if password.get() == confirm_password.get():
                    expense_tracker_backend.register_user(username.get(), fullname.get(), password.get())
                    expense_tracker_backend.getUserId(username.get(), password.get())
                    controller.show_frame(DashboardPage)
                else:
                    tkinter.messagebox.showerror("Password", "Password and Confirm Password not thesame")
            else:
                tkinter.messagebox.showerror("Input Field", "Make sure You input something in every field")

        # =====================================Frame==========================================

        # Form Tittle
        label_title = Label(self, text='Sign Up', font='Poppins 18', background=None)
        label_title.place(x=82, y=20, background=None)

        # Fullname Field
        label_full_name = Label(self, text='FUll Name:', font='Poppins 14', bg=None)
        label_full_name.place(x=82, y=70)

        entry_full_name = Entry(self, width=50, font='Poppins 14', textvariable=fullname)
        entry_full_name.place(x=82, y=120, background=None)

        # Username Field
        label_username = Label(self, text='Username', font='Poppins 14', bg=None)
        label_username.place(x=82, y=170)

        entry_username = Entry(self, width=50, font='Poppins 14', textvariable=username)
        entry_username.place(x=82, y=200, background=None)

        # Password Field
        label_password = Label(self, text='Password', font='Poppins 14', bg=None)
        label_password.place(x=82, y=240)

        entry_password = Entry(self, width=50, font='Poppins 14', bg=None, textvariable=password)
        entry_password.place(x=82, y=270)

        # Confirm Password Field
        label_confirm_password = Label(self, text='Confirm Password', font='Poppins 14', bg=None)
        label_confirm_password.place(x=82, y=310)

        entry_confirm_password = Entry(self, width=50, font='Poppins 14', bg=None, textvariable=confirm_password)
        entry_confirm_password.place(x=82, y=340)

        # Sign in Button
        sign_up_button = Button(self, text='Sign Up', width=59, font='Poppins 12', height=1, bg='blue', fg='white',
                                command=sign_up_onclick)
        sign_up_button.place(x=82, y=390)

        question = Label(self, text='Already Have an Account?', font='Poppins 13', bg=None)
        question.place(x=82, y=470)

        sign_in_button = Button(self, text='Sign In', width=59, font='Poppins 12', height=1, bg='white', fg='black',
                                command=lambda: controller.show_frame(StartPage))
        sign_in_button.place(x=82, y=500)

# ================================== DashBoard Frame ============================================

class DashboardPage(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent, width=800, height=600)

        # ==================================== Attributes =============================================
        budget_input = IntVar()

        # ==================================== Method ==================================================

        def update_budget_click():
            if(budget_input.get() > 0):
                expense_tracker_backend.update_budget(int(budget_input.get()))


        # ===================================== Main Frame ==============================================
        main_frame = Frame(self, bg="#eaeaea")
        main_frame.grid()

        # ===================================== Left Frame ==============================================

        left_frame = Frame(main_frame, bd=2, padx=2, pady=150.6)
        left_frame.pack(side=LEFT)

        dashboard_button = Button(left_frame, text="Dashboard", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                  command=lambda: controller.show_frame(DashboardPage))
        dashboard_button.grid()

        add_income_button = Button(left_frame, text="Add Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                   command=lambda: controller.show_frame(AddIncomePage))
        add_income_button.grid()

        add_expenses_button = Button(left_frame, text="Add Expenses", width=15, font='Poppins 12', height=1,
                                     bg='#eaeaea', command=lambda: controller.show_frame(AddExpensesPage))
        add_expenses_button.grid()

        show_income_button = Button(left_frame, text="Show Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                    command=lambda: controller.show_frame(ShowIncomePage))
        show_income_button.grid()

        show_expenses_button = Button(left_frame, text="Show Expenses", width=15, font='Poppins 12', height=1,
                                      bg='#eaeaea', command=lambda: controller.show_frame(ShowExpensesPage))
        show_expenses_button.grid()

        logout_button = Button(left_frame, text="Log out", width=15, font='Poppins 12', height=1, bg='#eaeaea', command=lambda: controller.show_frame(StartPage))
        logout_button.grid()

        # ==================================== RIGHT FRAME ========================================

        # ================ Budget Frame ===================================

        budget_frame = Frame(self, width=200, height=200, bd=2, padx=42, pady=42, relief=RIDGE, bg="white")
        budget_frame.place(x=600, y=113)

        budget_info = Label(budget_frame, text='Budget', font='Poppins 12', bg='white')
        budget_info.grid()

        budget_value = Label(budget_frame, text=expense_tracker_backend.view_user_budget()[0][0], font='Poppins 14 bold', fg='blue', bg='white')
        budget_value.grid()

        budget_value = Label(budget_frame, text='naira', font='Poppins 12', fg='blue', bg='white')
        budget_value.grid()

        # ================ Expense Frame ===================================

        expense_frame = Frame(self, width=200, height=200, bd=2, padx=42, pady=42, relief=RIDGE, bg="white")
        expense_frame.place(x=383, y=113)

        income_info = Label(expense_frame, text='Total Expenses', font='Poppins 12', bg='white')
        income_info.grid()

        income_value = Label(expense_frame, text=expense_tracker_backend.total_expenses(), font='Poppins 14 bold', fg='blue', bg='white')
        income_value.grid()

        income_value = Label(expense_frame, text='naira', font='Poppins 12', fg='blue', bg='white')
        income_value.grid()

        # ================================ Income Frame ===================================

        income_frame = Frame(self, width=200, height=200, bd=2, padx=42, pady=42, relief=RIDGE, bg="white")
        income_frame.place(x=180, y=113)

        income_info = Label(income_frame, text='Total Income', font='Poppins 12', bg='white')
        income_info.grid()

        income_value = Label(income_frame, text=expense_tracker_backend.total_incomes(), font='Poppins 14 bold', fg='blue', bg='white')
        income_value.grid()

        income_value = Label(income_frame, text='naira', font='Poppins 12', fg='blue', bg='white')
        income_value.grid()

        # ================================ Update Budget Section ============================================

        budget_title = Label(self, text='UPDATE BUDGET', font='Poppins 14 bold', fg='blue')
        budget_title.place(x=400, y=400)

        budget_entry = Entry(self, width=46, font='Poppins 14', bg='#eaeaea', bd=2, textvariable=budget_input)
        budget_entry.place(x=190, y=450, background=None)

        update_budget_button = Button(self, text='Update Budget', width=20, font='Poppins 12', height=1, command=update_budget_click)
        update_budget_button.place(x=350, y=500)



# ================================= Add Income Frame ====================================================


class AddIncomePage(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent, width=800, height=600)

        main_frame = Frame(self, bg="#eaeaea")
        main_frame.grid()

        # =================================== Attributes ==============================================

        amount_input = IntVar()
        source_input = StringVar()

        # ==================================== Method ==================================================

        def add_income():
            if (len(source_input.get()) > 0 and amount_input.get() > 0):
                expense_tracker_backend.add_income(amount_input.get(), source_input.get(), user_id)
                tkinter.messagebox.showinfo("Success", "Successfully Added")
            else:
                tkinter.messagebox.showerror("Element Required", "Fill All Field Provided")

        # ===================================== Left Frame ==============================================

        left_frame = Frame(main_frame, bd=2, padx=2, pady=150.6)
        left_frame.pack(side=LEFT)

        dashboard_button = Button(left_frame, text="Dashboard", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                  command=lambda: controller.show_frame(DashboardPage))
        dashboard_button.grid()

        add_income_button = Button(left_frame, text="Add Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                   command=lambda: controller.show_frame(AddIncomePage))
        add_income_button.grid()

        add_expenses_button = Button(left_frame, text="Add Expenses", width=15, font='Poppins 12', height=1,
                                     bg='#eaeaea', command=lambda: controller.show_frame(AddExpensesPage))
        add_expenses_button.grid()

        show_income_button = Button(left_frame, text="Show Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                    command=lambda: controller.show_frame(ShowIncomePage))
        show_income_button.grid()

        show_expenses_button = Button(left_frame, text="Show Expenses", width=15, font='Poppins 12', height=1,
                                      bg='#eaeaea', command=lambda: controller.show_frame(ShowExpensesPage))
        show_expenses_button.grid()

        logout_button = Button(left_frame, text="Log out", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                               command=lambda: controller.show_frame(StartPage))
        logout_button.grid()

        # ===================================== Right Frame ==============================================

        title = Label(self, text="ADD INCOME", font='Poppins 18', height=1, bg='#eaeaea')
        title.place(x=400, y=30)

        source = Label(self, text="Source", font='Poppins 14', height=1, bg='#eaeaea')
        source.place(x=250, y=100)

        entry_source = Entry(self, width=38, font='Poppins 14', bg='#eaeaea', bd=2, textvariable=source_input)
        entry_source.place(x=250, y=150, background=None)

        amount = Label(self, text="Amount", font='Poppins 14', height=1, bg='#eaeaea')
        amount.place(x=250, y=200)

        entry_amount = Entry(self, width=38, font='Poppins 14', bg='#eaeaea', bd=2, textvariable=amount_input)
        entry_amount.place(x=250, y=250, background=None)

        add_income_butotn = Button(self, text='Add Income', width=20, font='Poppins 12', height=1, command=add_income)
        add_income_butotn.place(x=370, y=300)


# ============================================ Add Expenses Frame =====================================================

class AddExpensesPage(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent, width=800, height=600)

        main_frame = Frame(self, bg="#eaeaea")
        main_frame.grid()

        # ================================== Attributes ===========================================

        expenses_category_input = StringVar()
        expenses_description_input = StringVar()
        expenses_amount_input = IntVar()

        # ==================================== Method ==================================================

        def add_expenses_tap():
            if (len(expenses_category_input.get()) > 0 and len(
                    expenses_description_input.get()) > 0 and expenses_amount_input.get() > 0):
                expense_tracker_backend.add_expenses(expenses_amount_input.get(), expenses_category_input.get(), user_id,
                                             expenses_description_input.get())
                tkinter.messagebox.showinfo("Success", "Successfully Added")
            else:
                tkinter.messagebox.showerror("Required Filed", "No field should be empty")

        # ===================================== Left Frame ==============================================
        left_frame = Frame(main_frame, bd=2, padx=2, pady=150.6)
        left_frame.pack(side=LEFT)

        dashboard_button = Button(left_frame, text="Dashboard", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                  command=lambda: controller.show_frame(DashboardPage))
        dashboard_button.grid()

        add_income_button = Button(left_frame, text="Add Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                   command=lambda: controller.show_frame(AddIncomePage))
        add_income_button.grid()

        add_expenses_button = Button(left_frame, text="Add Expenses", width=15, font='Poppins 12', height=1,
                                     bg='#eaeaea', command=lambda: controller.show_frame(AddExpensesPage))
        add_expenses_button.grid()

        show_income_button = Button(left_frame, text="Show Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                    command=lambda: controller.show_frame(ShowIncomePage))
        show_income_button.grid()

        show_expenses_button = Button(left_frame, text="Show Expenses", width=15, font='Poppins 12', height=1,
                                      bg='#eaeaea', command=lambda: controller.show_frame(ShowExpensesPage))
        show_expenses_button.grid()

        logout_button = Button(left_frame, text="Log out", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                               command=lambda: controller.show_frame(StartPage))
        logout_button.grid()

        # ===================================== Right Frame ==============================================

        title = Label(self, text="ADD EXPENSES", font='Poppins 18', height=1, bg='#eaeaea')
        title.place(x=400, y=30)

        category = Label(self, text="category", font='Poppins 14', height=1, bg='#eaeaea')
        category.place(x=250, y=100)

        entry_category = Entry(self, width=38, font='Poppins 14', bg='#eaeaea', bd=2,
                               textvariable=expenses_category_input)
        entry_category.place(x=250, y=150, background=None)

        description = Label(self, text="Description", font='Poppins 14', height=1, bg='#eaeaea')
        description.place(x=250, y=200)

        entry_description = Entry(self, width=38, font='Poppins 14', bg='#eaeaea', bd=2,
                                  textvariable=expenses_description_input)
        entry_description.place(x=250, y=250, background=None)

        amount = Label(self, text="Amount", font='Poppins 14', height=1, bg='#eaeaea')
        amount.place(x=250, y=300)

        entry_amount = Entry(self, width=38, font='Poppins 14', bg='#eaeaea', bd=2, textvariable=expenses_amount_input)
        entry_amount.place(x=250, y=350, background=None)

        add_expenses_but = Button(self, text='Add Expenses', width=20, font='Poppins 12', height=1,
                                  command=add_expenses_tap)
        add_expenses_but.place(x=370, y=400)


# ====================================== Show Income Frame =====================================

class ShowIncomePage(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent, width=800, height=600)

        main_frame = Frame(self, bg="#eaeaea")
        main_frame.grid()

        # ==================================== Method ==================================================


        # ===================================== Left Frame ==============================================
        left_frame = Frame(main_frame, bd=2, padx=2, pady=150.6)
        left_frame.pack(side=LEFT)

        dashboard_button = Button(left_frame, text="Dashboard", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                  command=lambda: controller.show_frame(DashboardPage))
        dashboard_button.grid()

        add_income_button = Button(left_frame, text="Add Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                   command=lambda: controller.show_frame(AddIncomePage))
        add_income_button.grid()

        add_expenses_button = Button(left_frame, text="Add Expenses", width=15, font='Poppins 12', height=1,
                                     bg='#eaeaea', command=lambda: controller.show_frame(AddExpensesPage))
        add_expenses_button.grid()

        show_income_button = Button(left_frame, text="Show Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                    command=lambda: controller.show_frame(ShowIncomePage))
        show_income_button.grid()

        show_expenses_button = Button(left_frame, text="Show Expenses", width=15, font='Poppins 12', height=1,
                                      bg='#eaeaea', command=lambda: controller.show_frame(ShowExpensesPage))
        show_expenses_button.grid()

        logout_button = Button(left_frame, text="Log out", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                               command=lambda: controller.show_frame(StartPage))
        logout_button.grid()

        # ===================================== Right Frame ==============================================

        title = Label(self, text='INCOME LIST', font='Poppins 18 bold', height=1, bg='#eaeaea')
        title.place(x = 380, y = 10)

        tree = ttk.Treeview(self, height=24)

        tree["columns"] = ("one", "two", "three")
        tree.column("#0", width=50, minwidth=50, stretch=NO)
        tree.column("one", width=200, minwidth=200, stretch=NO)
        tree.column("two", width=100, minwidth=100)
        tree.column("three", width=190, minwidth=150, stretch=NO)

        tree.heading("#0", text="ID", anchor=W)
        tree.heading("one", text="Source", anchor=W)
        tree.heading("two", text="Amount", anchor=W)
        tree.heading("three", text="Date", anchor=W)

        for id, amount, source, date, users_id in expense_tracker_backend.view_income():
            tree.insert("", 1, text=id, values=(source, amount, date))

        tree.place(x = 200, y = 50)


# ================================ Show Expenses Frame =================================

class ShowExpensesPage(Frame):
    def __init__(self, parent, controller):
        Frame.__init__(self, parent, width=800, height=600)

        main_frame = Frame(self, bg="#eaeaea")
        main_frame.grid()

        # ==================================== Method ==================================================


        # ===================================== Left Frame ==============================================
        left_frame = Frame(main_frame, bd=2, padx=2, pady=150.6)
        left_frame.pack(side=LEFT)

        dashboard_button = Button(left_frame, text="Dashboard", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                  command=lambda: controller.show_frame(DashboardPage))
        dashboard_button.grid()

        add_income_button = Button(left_frame, text="Add Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                   command=lambda: controller.show_frame(AddIncomePage))
        add_income_button.grid()

        add_expenses_button = Button(left_frame, text="Add Expenses", width=15, font='Poppins 12', height=1,
                                     bg='#eaeaea', command=lambda: controller.show_frame(AddExpensesPage))
        add_expenses_button.grid()

        show_income_button = Button(left_frame, text="Show Income", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                                    command=lambda: controller.show_frame(ShowIncomePage))
        show_income_button.grid()

        show_expenses_button = Button(left_frame, text="Show Expenses", width=15, font='Poppins 12', height=1,
                                      bg='#eaeaea', command=lambda: controller.show_frame(ShowExpensesPage))
        show_expenses_button.grid()

        logout_button = Button(left_frame, text="Log out", width=15, font='Poppins 12', height=1, bg='#eaeaea',
                               command=lambda: controller.show_frame(StartPage))
        logout_button.grid()

        # ===================================== Right Frame ==============================================

        title = Label(self, text='EXPENSES LIST', font='Poppins 18 bold', height=1, bg='#eaeaea')
        title.place(x=380, y=10)

        tree = ttk.Treeview(self, height=24)

        tree["columns"] = ("one", "two", "three", "four")
        tree.column("#0", width=50, minwidth=50, stretch=NO)
        tree.column("one", width=100, minwidth=100, stretch=NO)
        tree.column("two", width=170, minwidth=150, stretch=NO)
        tree.column("three", width=80, minwidth=50)
        tree.column("four", width=170, minwidth=150, stretch=NO)

        tree.heading("#0", text="ID", anchor=W)
        tree.heading("one", text="Category", anchor=W)
        tree.heading("two", text="Description", anchor=W)
        tree.heading("three", text="Amount", anchor=W)
        tree.heading("four", text="Date", anchor=W)

        for id, amount, category,description, date, users_id in expense_tracker_backend.view_expenses():
            tree.insert("", 1, text=id, values=(category, description, amount, date))

        tree.place(x=200, y=50)


app = App()
app.mainloop()
